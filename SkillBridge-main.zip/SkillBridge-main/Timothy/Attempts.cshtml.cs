using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyApp.Namespace
{
    public class AttemptsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
