using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

public class QuizModel : PageModel
{
    [BindProperty]
    public string Answer1 { get; set; }

    [BindProperty]
    public string Answer2 { get; set; }

    public string ErrorMessage { get; set; }

    public void OnGet()
    {
        // Initial page load
    }

    public IActionResult OnPost()
    {
        // Validate inputs
        if (string.IsNullOrEmpty(Answer1) || string.IsNullOrEmpty(Answer2))
        {
            ErrorMessage = "Please answer all questions.";
            return Page();
        }

        // Calculate score
        int score = 0;
        if (Answer1 == "Paris") score++;
        if (Answer2 == "Mars") score++;

        // Redirect to result page with score
        return RedirectToPage("./Review", new { score });
    }
}
