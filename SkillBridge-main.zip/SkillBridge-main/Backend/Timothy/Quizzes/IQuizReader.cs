namespace SkillBridge.Web.Features.Quizzes;

public interface IQuizReader
{
    Task<QuizOverview?> GetOverviewAsync(long quizId, long userId, bool canPreviewDraft, CancellationToken cancellationToken);
    Task<IReadOnlyList<QuizSummary>> GetAllAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<QuizAttemptSummary>> GetAttemptsAsync(long quizId, long userId, CancellationToken cancellationToken);
}

public sealed record QuizAttemptSummary(
    long AttemptId, 
    int AttemptNumber, 
    DateTime SubmittedAt, 
    int Score, 
    int TotalQuestions, 
    bool IsPassed
);