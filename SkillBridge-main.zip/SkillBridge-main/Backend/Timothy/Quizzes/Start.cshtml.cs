using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SkillBridge.Web.Features.Quizzes;
using MySqlConnector;
using SkillBridge.Web.Infrastructure.Data;

namespace SkillBridge.Web.Pages.Timothy.Quizzes;

public class StartModel : PageModel
{
    private readonly IQuizReader _quizReader;

    public StartModel(IQuizReader quizReader)
    {
        _quizReader = quizReader; //read quiz
    }

    public QuizOverview Quiz { get; set; } = default!;
    public IReadOnlyList<QuizAttemptSummary> PreviousAttempts { get; set; } = [];
    public QuizAttemptSummary? LastAttempt => PreviousAttempts.FirstOrDefault();

    public async Task<IActionResult> OnGetAsync(long quizId, CancellationToken cancellationToken)
    {
        long? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            return RedirectToPage("/JianYi/Account/Login"); //if not authenticate return to login page..
        }

        bool isAdmin = User.IsInRole("Admin");
        var overview = await _quizReader.GetOverviewAsync(quizId, userId.Value, isAdmin, cancellationToken);
        if (overview == null)
        {
            return NotFound();
        }

        Quiz = overview;
        PreviousAttempts = await _quizReader.GetAttemptsAsync(quizId, userId.Value, cancellationToken);
        return Page();
    }
}