public class Question1
{
    public string QuestionText { get; set; }       // Holds the question text
    public string[] Options { get; set; }          // Holds the answer options
    public int CorrectAnswerIndex { get; set; }    // Holds the index of the correct answer
}
// for the Questions which there is DB for it FROM my module
public class Question2
{
    public string QuestionText { get; set; }       // Holds the question text
    public string[] Options { get; set; }          // Holds the answer options
    public int CorrectAnswerIndex { get; set; }    // Holds the index of the correct answer
}
public class ResultModel
{
    public int Score { get; set; }

    public void OnGet(int score)
    {
        Score = score;
    }
}
// for the results, questions and attempts. 