using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SkillBridge.Web.Features.Quizzes;
using SkillBridge.Web.Infrastructure.Data;
using MySqlConnector;
//https://github.com/ZubairAhmed01719/Quiz-Project-C-.NET-Based-Application/blob/main/quizselection.Designer.cs
namespace SkillBridge.Web.Pages.Timothy
{
    public class AttemptModel : PageModel
    {
    private readonly IConfiguration _configuration;
    public AttemptModel(IConfiguration configuration) => _configuration = configuration;

    public record QuestionVm(long Id, int SequenceNumber, string Text, int Marks, List<OptionVm> Options);
    public record OptionVm(long Id, string Text, int SequenceNumber);

    public QuestionVm CurrentQuestion { get; set; } = default!;
    public int TotalQuestions { get; set; }
    public int CurrentSequence { get; set; }
    [BindProperty] public long SelectedOptionId { get; set; }

    public async Task<IActionResult> OnGetAsync(long quizId, int? seq, CancellationToken cancellationToken)
    {
        long? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null) return RedirectToPage("/Login");

        CurrentSequence = seq ?? 1;

        string connString = _configuration.GetConnectionString("DefaultConnection") ?? "";
        await using var conn = new MySqlConnection(connString);
        await conn.OpenAsync(cancellationToken);

        // Get question count
        await using var countCmd = conn.CreateCommand();
        countCmd.CommandText = "SELECT COUNT(*) FROM questions WHERE quiz_id = @quizId";
        countCmd.Parameters.AddWithValue("@quizId", quizId);
        TotalQuestions = Convert.ToInt32(await countCmd.ExecuteScalarAsync(cancellationToken));

        // Get current question
        await using var qCmd = conn.CreateCommand();
        qCmd.CommandText = "SELECT id, question_text, marks FROM questions WHERE quiz_id = @quizId AND sequence_number = @seq";
        qCmd.Parameters.AddWithValue("@quizId", quizId);
        qCmd.Parameters.AddWithValue("@seq", CurrentSequence);

        await using var reader = await qCmd.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) return NotFound();

        long qId = reader.GetInt64("id");
        CurrentQuestion = new QuestionVm(
            qId,
            CurrentSequence,
            reader.GetString("question_text"),
            reader.GetInt32("marks"),
            []
        );
        await reader.CloseAsync();

        // Get options
        await using var oCmd = conn.CreateCommand();
        oCmd.CommandText = "SELECT id, option_text, sequence_number FROM options WHERE question_id = @qId ORDER BY sequence_number";
        oCmd.Parameters.AddWithValue("@qId", qId);
        await using var oReader = await oCmd.ExecuteReaderAsync(cancellationToken);
        while (await oReader.ReadAsync(cancellationToken))
        {
            CurrentQuestion.Options.Add(new OptionVm(
                oReader.GetInt64("id"),
                oReader.GetString("option_text"),
                oReader.GetInt32("sequence_number")
            ));
        }

        return Page();
    }
    public void OnGet(){
            
            // attempt cannot be edited directly but uses a count 
            //+
        }
    }
}
