using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MySqlConnector;

namespace SkillBridge.Web.Pages.Timothy;

public class ReviewModel : PageModel
{
    private readonly IConfiguration _configuration;
    public ReviewModel(IConfiguration configuration) => _configuration = configuration;

    public record QuestionReviewVm(
        int SequenceNumber,
        string QuestionText,
        int Marks,
        string Explanation,
        List<OptionReviewVm> Options
    );

    public record OptionReviewVm(
        long Id,
        string Text,
        int SequenceNumber,
        bool IsCorrect,
        bool IsSelected
    );

    public string QuizTitle { get; set; } = "";
    public string CourseTitle { get; set; } = "";
    public int AttemptNumber { get; set; }
    public int Score { get; set; }
    public int TotalMarks { get; set; }
    public bool IsPassed { get; set; }
    public DateTime SubmittedAt { get; set; }
    public List<QuestionReviewVm> Questions { get; set; } = [];

    public async Task<IActionResult> OnGetAsync(long attemptId, CancellationToken cancellationToken)
    {
        long? userId = HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            return RedirectToPage("/Login");
        }

        string connString = _configuration.GetConnectionString("DefaultConnection") ?? "";
        await using var conn = new MySqlConnection(connString);
        await conn.OpenAsync(cancellationToken);

        // 1. Fetch Attempt Summary using schema columns: earned_marks, maximum_marks, submitted_at_utc, status
        await using var attCmd = conn.CreateCommand();
        attCmd.CommandText = """
            SELECT a.quiz_id, a.earned_marks, a.maximum_marks, a.submitted_at_utc,
                   q.title AS quiz_title, c.title AS course_title
            FROM attempts a
            INNER JOIN quizzes q ON q.id = a.quiz_id
            INNER JOIN courses c ON c.id = q.course_id
            WHERE a.id = @attemptId AND a.user_id = @userId AND a.status = 'Submitted';
            """;
        attCmd.Parameters.AddWithValue("@attemptId", attemptId);
        attCmd.Parameters.AddWithValue("@userId", userId.Value);

        long quizId = 0;
        decimal passPercentage = 60.00m;

        await using var reader = await attCmd.ExecuteReaderAsync(cancellationToken);
        if (await reader.ReadAsync(cancellationToken))
        {
            quizId = reader.GetInt64("quiz_id");
            Score = reader.IsDBNull(reader.GetOrdinal("earned_marks")) ? 0 : reader.GetInt32("earned_marks");
            TotalMarks = reader.IsDBNull(reader.GetOrdinal("maximum_marks")) ? 5 : reader.GetInt32("maximum_marks");
            SubmittedAt = reader.GetDateTime("submitted_at_utc");
            QuizTitle = reader.GetString("quiz_title");
            CourseTitle = reader.GetString("course_title");
        }
        else
        {
            return NotFound();
        }
        await reader.CloseAsync();

        // Fetch pass percentage threshold from quizzes table
        await using var qPassCmd = conn.CreateCommand();
        qPassCmd.CommandText = "SELECT pass_percentage FROM quizzes WHERE id = @quizId";
        qPassCmd.Parameters.AddWithValue("@quizId", quizId);
        var passVal = await qPassCmd.ExecuteScalarAsync(cancellationToken);
        if (passVal != null && passVal != DBNull.Value)
        {
            passPercentage = Convert.ToDecimal(passVal);
        }

        IsPassed = TotalMarks > 0 && Score >= (TotalMarks * (passPercentage / 100.00m));

        // 2. Fetch Questions and Student's Selected Answer from the answers table
        await using var qCmd = conn.CreateCommand();
        qCmd.CommandText = """
            SELECT q.id, q.sequence_number, q.question_text, q.marks, q.explanation,
                   ans.selected_option_id
            FROM questions q
            LEFT JOIN answers ans ON ans.question_id = q.id AND ans.attempt_id = @attemptId
            WHERE q.quiz_id = @quizId
            ORDER BY q.sequence_number;
            """;
        qCmd.Parameters.AddWithValue("@quizId", quizId);
        qCmd.Parameters.AddWithValue("@attemptId", attemptId);

        await using var qReader = await qCmd.ExecuteReaderAsync(cancellationToken);
        var questionRows = new List<(long QId, int Seq, string Text, int Marks, string Expl, long? SelectedOptId)>();
        while (await qReader.ReadAsync(cancellationToken))
        {
            questionRows.Add((
                qReader.GetInt64("id"),
                qReader.GetInt32("sequence_number"),
                qReader.GetString("question_text"),
                qReader.GetInt32("marks"),
                qReader.GetString("explanation"),
                qReader.IsDBNull(qReader.GetOrdinal("selected_option_id")) ? null : qReader.GetInt64("selected_option_id")
            ));
        }
        await qReader.CloseAsync();

        // 3. Load Options for each question using schema columns (is_correct, sequence_number)
        foreach (var q in questionRows)
        {
            await using var optCmd = conn.CreateCommand();
            optCmd.CommandText = """
                SELECT id, option_text, sequence_number, is_correct
                FROM options
                WHERE question_id = @qId
                ORDER BY sequence_number;
                """;
            optCmd.Parameters.AddWithValue("@qId", q.QId);

            await using var optReader = await optCmd.ExecuteReaderAsync(cancellationToken);
            var options = new List<OptionReviewVm>();
            while (await optReader.ReadAsync(cancellationToken))
            {
                long optId = optReader.GetInt64("id");
                options.Add(new OptionReviewVm(
                    optId,
                    optReader.GetString("option_text"),
                    optReader.GetByte("sequence_number"),
                    optReader.GetBoolean("is_correct"),
                    q.SelectedOptId.HasValue && q.SelectedOptId.Value == optId
                ));
            }

            Questions.Add(new QuestionReviewVm(q.Seq, q.Text, q.Marks, q.Expl, options));
        }

        return Page();
    }
}